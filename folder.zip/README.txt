LIBRARIES TO RUN THE SCRIPT

numpy
pandas
Sklearn
datetime
matplotlib
XGBoost - need to be downloaded to anaconda using
		conda install -c anaconda py-xgboost

script - pip install -r requirements.txt

to run the code, run script in the terminal go to folder where .py file is present and type
script : python code.py 



